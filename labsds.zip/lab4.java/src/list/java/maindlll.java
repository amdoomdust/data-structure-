/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package list.java;

import static list.java.stack.checkBalance;

/**
 *
 * @author dddoo
 */
public class maindlll {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
     
          
          
          /* String exp = "[]{}()";
        if (checkBalance(exp)) {
            System.out.println(exp + " is balance");
        } else {
            System.out.println(exp + " is not balance");
        }*/
        
        stack lis = new stack();
        
        lis.pop();
        char x='m';
        E b=new E(x);
        lis.push(b);
        
        char c='b';
        E t=new E(c);
        lis.push(t);
        
        char r='h';
        E tk=new E(r);
        lis.push(tk);
        
      
        
        
        
     
        System.out.println("top is >"+lis.top().getValue());
        System.out.println("pop>"+lis.pop().getValue());
        System.out.println("top is >"+lis.top().getValue());
        
        


        
        
        
        
        
        
        
        
        
        
    }
    
}
