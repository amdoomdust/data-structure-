/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package list.java;

/**
 *
 * @author dddoo
 */
public interface list<E> {
    
    
    
 void addFront(E x); //Add Element at the beginning of the list
 void addEnd(E x); //Add Element at the end of the list
 void addMid(E val , E x); //Add Element after the value val in the list
 void print(); // print all the elements in the list
 boolean empty();// return true if the list is empty
 void removeEnd();// remove the last element in the list
 E removeFront();// remove the first element in the list
 void remove(E x);// remove the element x from the list
 void removeAll();// remove all elements in the list
 boolean exist(E x);// check if the element x is in the list


    
}
