/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package list.java;

/**
 *
 * @author dddoo
 */
public class ListJava<E> implements  list<E> {
   private Node head =null; 
 
    
   @Override
 public  void addFront(E x){
 Node node = new Node(x);
 node.next=head;
 head=node;
 
 
 }; //Add Element at the beginning of the list
 
 
 
   @Override
 public void addEnd(E x){
  if(empty()){
    addFront(x);
}
 
 Node temp =head;
 
 while(temp.next != null){
     temp=temp.next;
    
}
 Node node = new Node(x);
 
 temp.next=node;
 
 
 
 
 
 
 
 }; //Add Element at the end of the list

 
 
   @Override
 public  void addMid(E ser , E x){
 if(head==null){
    System.out.println("list is empty");
 }
 
 Node temp= head;
 
 while(temp.next!=null&&temp.data!=ser){
     temp=temp.next;
 }
 
 if(temp.data!=ser){
    System.out.println("value is not in list"+ ser);
    
 }else{
     Node node= new Node(x);
     node.next=temp.next;
     temp.next=node; 
 }
 
 }; //Add Element after the value val in the list
 
 
   @Override
 public void print(){
 Node temp= head;
 
 while(temp!=null){
     System.out.print(temp.data+"->");
     temp=temp.next;
 }
 
System.out.println("End");
 
 
 
 }; // print all the elements in the list
 
 
   @Override
 public boolean empty(){
 if (head==null){
     return true;
 }
 return false;
 
 };// return true if the list is empty
 
 
 public void removeEnd(){
 Node temp=head;

 if(head.next==null){
  head=null;
  

 }else{
 
 
 while(temp.next.next!=null){
     temp=temp.next;
 }
 
 temp.next=null;}
 

 
 
 
 };// remove the last element in the list
 
 public E removeFront(){
     if(empty()){
       System.out.println("list is empty"); 
       return null;
     }else{
         Node temp=head;
         head=head.next;
         temp.next=null;
         return temp.data;
     }
        
     
 }
 
 
 public void remove(E x){
     Node temp=head;
 if(head.data==x){
     head=head.next;
 }else{
     while(temp.next!=null&&temp.next.data!=x){
     temp=temp.next;
     }
 }
 if(temp.next.data==x){
     temp.next=(temp.next).next;
 }
 
 
 
 };// remove the element x from the list
 
 
 public void removeAll(){
 head=null;
 
 };// remove all elements in the list
 
 
 public boolean exist(E x){
 if(head==null){
     return false;
 }
 
 Node temp=head;
 
 while(temp.next!=null&&temp.data!=x){
     temp=temp.next;
 }
 

 if(temp.data!=x){
     return false;
 }
 
 return true;
    
 
 
 
 
 
 };// check if the element x is in the list

  public E gethead(){
      if(!empty()){
     return head.data;}else{
          return null;
      }
          
  }
 
 
 private class Node{
     private E data;
    private Node next;
    
    public  Node(E data){
        this.data=data;
        this.next=null;
    }
    
    public  Node (E data,Node n){
        this.data=data;
        this.next=n;
    }
    
     @Override
    public String toString(){
 return data+ " ";
 }

             
 }

    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
