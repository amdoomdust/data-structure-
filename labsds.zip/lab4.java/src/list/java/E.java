/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package list.java;

/**
 *
 * @author dddoo
 */
public  class E {
 char data;

public E(char character) {
    this.data=character;
}
    


public char getValue(){
return this.data;
}

}
