/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author NAWAF
 */
interface List {

    void addFront(int x); //Add Element at the beginning of the list

    void addEnd(int x); //Add Element at the end of the list

    void addMid(int val, int x); //Add Element after the value val in the list

    void print(); // print all the elements in the list

    boolean empty();// return true if the list is empty

    void removeEnd();// remove the last element in the list

    void removeFront();// remove the first element in the list

    void remove(int x);// remove the element x from the list

    void removeAll();// remove all elements in the list

    boolean exist(int x);// check if the element x is in the list
}
