/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayproject;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author dddoo
 */
public class ArrayProject {


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner input= new Scanner(System.in);
     System.out.println("enter size of 1d array\n");
     int size=1;
     size=input.nextInt();
     
 int test1D[] = new int[size];
 fillArray_1D(test1D,size); 
 printArray_1D(test1D,size);
 
 
 
 //task 1 avg and swap
double avg= belowAboveAvg(test1D,size);
System.out.println("avg is= \n"+avg);

//task 2 swapLargestSmallest
int small= swapLargestSmallest(test1D,size);
System.out.println("swaping the large with the small :-\n");
printArray_1D(test1D,size);

//2d
int[][] test2D= new int[10][10];
fillArray_2D(test2D);
System.out.println("/n2d arrays:");
printArray_2D(test2D);

//Task3: Finds and displays sum of each row and each column of the 2D
//array., by calling SumRowsColumns() method.
System.out.println("");
sumRowsColumns(test2D);

//Task4: Displays row(s) which contain(s) repeated elements
System.out.println("");
repeatedElementsRow(test2D);










 
 
 
 
     
     
        
        
        
        
        
        
        
        
        
        
    }
    
     static void fillArray_1D(int array[],int size)
{  Random rand = new Random();
   for(int i = 0; i < size; i++) {
   array[i] = rand.nextInt(100);
   
   
}
    
    
}
    static void fillArray_2D(int[][] array){
Random rand = new Random();

for(int i = 0; i < 10; i++) {

    for(int j = 0; j < 10; j++) {

        array[i][j]=rand.nextInt(100) ;
}

}
     }
     
   static void printArray_1D (int array[],int size){
        for(int i = 0; i < size; i++) {
   System.out.println("element ["+i+"]="+ array[i]);
}
    }
    
    
     static void printArray_2D (int array[][]){
       for(int i = 0; i < 10; i++) {
for(int j = 0; j < 10; j++) {
System.out.println("element["+i+"]["+j+"]="+ array[i][j]);
}
    }
}
     static double belowAboveAvg (int array[],int size){
          double tot =array[0];
          for (int i = 1; i < size; i++) {
              tot=tot+array[i];
          }
          double avg=tot/size;
          for (int i = 0; i < size; i++) {
              if(array[i]>avg){
                  System.out.println("array["+i+ "]= "+array[i]+" is bigger then avg "+avg);
                  
              }else
                  if(array[i]<avg){
                       System.out.println("array["+i+ "]= "+array[i]+" is less then avg "+avg);
                  }
             
         }
          return avg;
          
          
          
      }
      static int swapLargestSmallest(int array[],int size){
      int small= array[0];
      int large=array[0];
      int count=1;
      while(count<size){
          if(array[count]<small){
              small=array[count];}
          count++;
      }
      count=1;
      while(count<size){
          if(array[count]>large){
              large=array[count];}
          count++;
      }
      int largenum=0;
      while(large!=array[largenum]){
          largenum++;
      }
          int smallnum=0;
      while(small!=array[smallnum]){
          smallnum++;
         
      }
      array[largenum]=small;
      array[smallnum]=large;
              
              
      
      return small;
      }
      
     static void sumRowsColumns(int array[][]){
          int sumrow=0;
          int sumcol=0;
          for (int i = 0; i < 10; i++) {
              
              for (int j = 0; j < 10; j++) {
                sumrow =sumrow+array[i][j];
              }
              
              System.out.println("sum row["+i+"]="+sumrow);
              
              sumrow=0;
          }
          
          for (int i = 0; i < 10; i++) {
              
              for (int j = 0; j < 10; j++) {
                sumcol =sumcol+array[j][i];
              }
              System.out.println("sum col["+i+"]="+sumcol);
              
              sumcol=0;
              
          }
          
         
          
      }
         static void repeatedElementsRow(int array[][]){
              
              int chk=0;
              
              for (int a = 0; a < 10; a++) {
                 
                  for (int i = 0; i < 10; i++) {
                      chk=array[a][i];
                      for (int b =i+1; b < 4; b++) {
               if(chk==array[a][b]){
                   System.out.println("repeted row int 2d array row["+a+"]:");
                   for (int j = 0; j < 4; j++) {
                       System.out.print(array[a][j] + " ");
                       
                   } System.out.println("");
                   
                   
               }else
                   System.out.println("\nno repeted ");
            }
                  }
                  
              }
              
            
            
              
      }
}





