/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectds;

/**
 *
 * @author dddoo
 */
public class E {
    
    
    String first_day;
    String Name;
    String Pnum;
    String Adrs;
    int work_hours;
    int salary;
    
    public E (String day,String name,String pnum,String adrs,int sal,int w_hour){
        
        this.Name=name;
        this.Adrs=adrs;
        this.first_day=day;
        this.Pnum=pnum;
        this.salary=sal;
        this.work_hours=w_hour;
        
        
    }

    E() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void show(){
        if(this.work_hours==0){
            
        }else{
        System.out.println("Name: "+this.Name+"\nPhone number: "+this.Pnum+"\nAdrees: "+this.Adrs+
                "\nSalary: "+this.salary+"\nFrist day: "+this.first_day+"\nwork hours: "+this.work_hours+"\n");
        }
        }
    public void upstring(String pnum, String adrs, int w_hour){
        this.Pnum=pnum;
        this.Adrs=adrs;
        this.work_hours=w_hour;
    }
    
    public void upsal(int sal){
        this.salary=sal;
    }
    
    public int workhour(){
        return this.work_hours;
    }
    
    public int salary(){
        return this.salary;
    }
    
    
    
}
