/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_searchingmethods;

/**
 *
 * @author dddoo
 */
import java.util.*;

/**
 *
 * @author NAWAF
 */

public class Lab2_SearchingMethods {


   static void fillArray(int array[],int size) {
        Random rand=new Random();
        for (int i = 0; i < size; i++) {
            array[i] = rand.nextInt(100);
        }
    }

    static int linearSearch(int array[],int size, int key) {
        for (int i = 0; i < size; i++) {
            if (key == array[i]) {
                return i; //If found, return index of that element
            }
        }
        return -1; //if not found, return -1
    }

   static int binarySearch(int array[], int size, int key) {
        int low = 0, high = size - 1, mid = 0;
        while (low <= high) {
            mid = (low + high) / 2;
            if (key == array[mid]) {
                return mid;
            } 
            else if (key < array[mid]) // change
                high =mid -1;
            else 
                low=mid+1;
        }
        return -1;
    }
    
            
                
    

    public static void main(String[] args) {
        
        int[] test=new int[100];
        long start,stop;
        Scanner input = new Scanner(System.in);
        
        
        System.out.print("enter size of array :");
        int size = input.nextInt();
        fillArray(test,size);
        
        System.out.print("Enter key to search :");
        int key=input.nextInt();
        
        
        start = System.nanoTime();
        System.out.println("linear search="+linearSearch(test, size,key ));
        stop = System.nanoTime();
        System.out.println("the time "+(stop-start));
        
        start = System.nanoTime();
        System.out.println("binary Search="+binarySearch(test, size ,key));
        stop = System.nanoTime();
        System.out.println("the time "+(stop-start));
        
    }

}