/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package list.java;

import java.util.LinkedList;

/**
 *
 * @author dddoo
 */
public class stack implements stackADT1<E> {
    
    

    private ListJava linked = new ListJava();

    @Override
    public void push(E x) {

        linked.addFront((E) x);
        System.out.println("push>"+x.getValue());
    }

    @Override
    public E pop() {
        if (linked.empty()) {
            System.out.println("empty stack");
            return null;
        } else {
            return (E) linked.removeFront();
        }

    }

    @Override
    public E top() {
        if (!isEmpty()) {
            return (E) linked.gethead();
        } else {
            return null;
        }

    }

    @Override
    public boolean isEmpty() {
        if (linked.gethead() == null) {
            return true;
        } else {
            return false;
        }
    }

   

    static boolean checkBalance(String expr) {
        stack stack = new stack();
        
        for (int i = 0; i < expr.length(); i++) {
            
            char character = expr.charAt(i);
            E x = new E(character);
            
            if (x.getValue() == '(' || x.getValue() == '[' || x.getValue() == '{') {

                stack.push(x);
                continue;
            }

            if (stack.isEmpty()) {
                return false;
            }

            char check;
            switch (x.getValue()) {
                case ')':
                    check = stack.pop().getValue();
                    if (check == '{' || check == '[') {
                        return false;
                    }
                    break;

                case '}':
                    check = stack.pop().getValue();
                    if (check == '(' || check == '[') {
                        return false;
                    }
                    break;

                case ']':
                    check = stack.pop().getValue();
                    if (check == '(' || check == '{') {
                        return false;
                    }
                    break;
            }
        }

        return (stack.isEmpty());
    }
    
    
    
    
}