/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

/**
 *
 * @author dddoo
 */
public interface QueueADT<E> {
     E dequeue();

    void enqueue(E x);

    boolean full();

    boolean isEmpty();
}
