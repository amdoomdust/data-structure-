/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author NAWAF
 */
class DNode{
    int data;
    DNode next;
    DNode previous;
    public DNode(int data){
        this.data = data;
        next = null;
        previous = null;
    }
    public String toString(){
         return data+ " ";
    }
}
