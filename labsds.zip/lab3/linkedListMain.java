/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author NAWAF
 */
public class linkedListMain {

    public static void main(String[] args) {
        LinkedList linked = new LinkedList();

        
        
        
        linked.print();
        linked.addFront(3);
        linked.addFront(8);
        linked.addFront(9);
        linked.print();
        linked.removeFront();
        
        linked.print();
        
        linked.removeEnd();
        linked.print();
        
        linked.remove(3);
        linked.print();
        
      if(linked.exist(5))
            System.out.println("the number is exist");
      else 
            System.out.println("the number is not exist");
        
       linked.removeAll();
        
        linked.print();
        
        
        
    }

}
