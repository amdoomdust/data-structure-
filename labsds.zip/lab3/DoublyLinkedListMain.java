/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author NAWAF
 */
public class DoublyLinkedListMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        DoublyLinkedList dlinked = new DoublyLinkedList();

        dlinked.addFront(5);
        dlinked.addFront(4);
        dlinked.addFront(3);
        
        dlinked.addEnd(6);
        dlinked.print();
        
        dlinked.removeFront();
        dlinked.print();
        
        

        if (dlinked.exist(5)) {
            System.out.println("the number is exist");
        } else {
            System.out.println("the number is not exist");
        }
        
        dlinked.remove(5);
        dlinked.print();
        
        dlinked.removeAll();
        dlinked.print();
        

    }

}
