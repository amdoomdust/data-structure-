/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectds;

/**
 *
 * @author dddoo
 */
public class Projectds {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        E emp1=new E("2023/4/4","feras shawli", "05050505", "alghnazy",4000,36);
         E emp2=new E("2023/4/3","fares m shawli", "05055555", "alghnazy2",5000,36);
          E emp3=new E("2023/8/4","akon zamba", "056666666", "jaja",60000,36);
          
          EmpLL list=new EmpLL();
          
          list.createrecord(emp1);
          list.createrecord(emp1);
          
          
          
          list.showemp(1);
          
                  list.createrecord(emp2);

          
        list.createrecord(emp3);
         
          
          list.showemp(2);
          list.showemp(3);
         int a= list.deleterecord(5);
          
          list.showemp(2);
          
          list.smartsearch(2).show();
          
          list.updateemp(1, "050502222", "maka", 50);
          list.updateemp(2, "05005555", "alghamdi",50);
          list.updatesalemp(2);
          list.updatesalemp(1);
         
          
          list.showemp(2);
          
          

          
          
          
          
          
         
         
        
        
    }
    
}
