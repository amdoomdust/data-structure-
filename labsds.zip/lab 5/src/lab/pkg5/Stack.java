/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

import java.util.LinkedList;

/**
 *
 * @author dddoo
 */
public class Stack   {
     private ListJava list=new ListJava();
    
    public void push(E x) {
        
         list.addFront((E)x);
    }

    
    public E pop() {
        if(list.empty())
        {
            System.out.println("empty stack!!!");
            return null;
        }else{
            return (E) list.removeFront();
        }
       
    }

    
    public E top() {
        if (!isEmpty()){
             return (E) list.gethead();
        }else{
            return null;
        }
       
    }

    public boolean isEmpty() {
        if(list.gethead()==null){
            return true;
        }else{
            return false;
        }
    }
}
