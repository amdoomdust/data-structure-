/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author NAWAF
 */
class LinkedList implements List {

    private Node head;

    public LinkedList() {
        head = null;
    }

    public void addFront(int x) {
        Node node = new Node(x);
        node.next = head;
        head = node;
    }

    public void addEnd(int x) {
        if (head == null) {
            addFront(x);
        } else {
            Node node = new Node(x);
            Node p = head;
            while (p.next != null) {
                p = p.next;
            }
            p.next = node;
        }
    }

    public void addMid(int val, int x) {
        if (empty()) {
            System.out.println("empty list!!!");
        } else {
            Node p = head;
            while (p.data != val && p.next != null) {
                p = p.next;
            }
            if (p.data != val) {
                System.out.println("The list doesn't have this value " + val);
            } else {
                Node node = new Node(x);
                node.next = p.next;
                p.next = node;
            }
        }
    }

    @Override
    public boolean empty() {
        if (head == null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void print() {
        if (empty()) {
            System.out.println("is empty ");
        } else {
            Node temp = head;

            while (temp != null) {
                System.out.println(temp.data);
                temp = temp.next;
            }
        }
    }

    @Override
    public void removeEnd() {
        Node temp = head;
        Node prev = null;

        if (empty()) {
            System.out.println("is empty ");
        } else {
            while (temp.next != null) {
                prev = temp;
                temp = temp.next;
            }
            prev.next = null;
            System.out.println("last node " + temp.data + "is deleted ");
        }

    }

    @Override
    public void removeFront() {
        Node temp = head;
        if (empty()) {
            System.out.println("is empty ");
        } else {
            head = head.next;
            temp.next = null;
            System.out.println("first node " + temp.data + "is deleted ");
        }
    }

    @Override
    public void remove(int x) {

        if (empty()) {
            System.out.println("list is empty");
        }

        Node temp = head;
        Node prev = null;
        while (temp.next != null && temp.data != x) {
            prev = temp;
            temp = temp.next;
        }

        if (temp.data != x) {
            System.out.println("value is not in list" + x);

        } else {
            prev.next = temp.next;
            temp = prev.next;
            System.out.println("Elment " + x + " has been deleted");
        }

    }

    @Override
    public void removeAll() {
       
            head = null;

    }

    @Override
    public boolean exist(int x) {
        Node temp = head;
        while (temp != null) {
            if (temp.data == x) {
                return true;
            }
            temp = temp.next;
        }
        return false;
    }

}
