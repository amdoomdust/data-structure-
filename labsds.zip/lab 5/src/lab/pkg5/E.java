/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

/**
 *
 * @author dddoo
 */
public class E {
    
   int value;

    public E(int value) {
        this.value = value;
    }
    public int getValue(){
        return this.value;
    }
    
    public int value(int a){
        this.value=a;
        return value;
    }
   

}
