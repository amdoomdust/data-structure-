/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectds;

/**
 *
 * @author dddoo
 */
public class EmpLL implements LLinter<E> {
    
    private Node head=null;
    private int idkey;
    private E def=new E("null","null", "null", "null",0,0);
    

    @Override
    public void createrecord(E e) {
       Node node= new Node(e);
        if(e.work_hours<32){
            System.out.println("cannot insert work hour less the 32");
        }else{
        if(checkrecord(e)){
         System.out.println("cannot insert\n ");
        }else{
        
        
        if(head==null){
            head=node;
            idkey++;
        }else{
            node.next=head;
            head=node;
            System.out.println("empleyer inserted");
            idkey++;
        }
            
        }
        }
    }

    @Override
    public int deleterecord(int id) {
        Node temp =head;
        
        while(temp.key!=id&&temp.next!=null){
            temp=temp.next;
        }
        
        if(temp.key==id){
            
        
        
 if(head.key==id){
     head=head.next;
     System.out.println("node has been deleted id: "+id);
     return 0;
 }else{
     while(temp.next!=null&&temp.next.key!=id){
     temp=temp.next;
    
     }
      
 }
 if(temp.next.key==id){
     temp.next=(temp.next).next;
     System.out.println("node has been deleted id: "+id);
     return 0;
 }else{
     return -1;
 }
 }else{
            System.out.println("no record for searched id");
            return -1;
        }
     }

    @Override
    public void showemp(int id) {
        Node temp=head;
        
         while(temp.key!=id&&temp.next!=null){
            temp=temp.next;
        }
        
        if(temp.key==id){
            System.out.println("ID: "+temp.key);
            temp.data.show();
        }else{
            System.out.println("no record to show for id: "+id+"\n");
        }
        
        
            
        
        
        
    }

    @Override
    public void updateemp(int id, String pnum, String adrs, int w_hour) {
        Node temp =head;
        
        if(w_hour<32){
            System.out.println("work hour is less then 32 cannot update");
        }else{
        
        while(temp.key!=id&&temp.next!=null){
            temp=temp.next;
        }
        
        if(temp.key==id){
            temp.data.upstring(pnum, adrs, w_hour);
            System.out.println("record id: "+id+"  has been updated");
        }else{
            System.out.println("ID might be wrong no record to update ");
        }
        }
    }

    @Override
    public void updatesalemp(int id) {
        Node temp =head;
        
        
        while(temp.key!=id&&temp.next!=null){
            temp=temp.next;
            
        }
        
        if(temp.key==id){
            
            if(temp.data.salary<32){
                System.out.println("salary less then 32");
            }else{
               int newsalary= (int)(temp.data.salary+((0.02*temp.data.salary)*(temp.data.work_hours-32)));
               temp.data.upsal(newsalary);
               System.out.println("salary updated id: "+id+"\n");
               
            }
            
            
            
            
        }else{
            System.out.println("ID might be wrong no record to update (salary) ");
        }
        
        
    }

    @Override
    public E smartsearch(int id) {
        Node temp =head;
        
        while(temp.key!=id&&temp.next!=null){
            temp=temp.next;
        }
        
        if(temp.key==id){
            return temp.data;
        }else{
            System.out.println("no record for searched id");
            return def;
        }
    }

    @Override
    public boolean checkrecord(E e) {
        if(head==null){
            System.out.println("head is null inserting as head\n");
            return false;
        }
        
        Node temp=head;
       
        
        while(temp.data!=e&&temp.next!=null){
            temp=temp.next;
        }
        if(temp.data==e){
            System.out.println("!!record alraedy exist!!");
            return true;
        }else
            return false;
            
        
        
    }
    
    
    
     private class Node{
     private E data;
    private Node next;
    private int key;
    
    
    public  Node(E data){
        this.data=data;
        this.next=null;
        this.key=idkey+1;
        
    }
    
    
    
     @Override
    public String toString(){
 return data+ " ";
 }
     }

     
 
    
   
 
    
}
