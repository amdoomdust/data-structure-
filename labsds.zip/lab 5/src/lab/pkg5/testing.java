/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

/**
 *
 * @author dddoo
 */
public class testing {
    public static void main(String[] args) {
           queue Q=new queue(9);
        System.out.println(Q.isEmpty());
        
        
        E x = new E(6);
        Q.enqueue(x);
        
        E b = new E(5);
        Q.enqueue(b);
        
        E c = new E(8);
        Q.enqueue(c);
        
        System.out.println(">"+Q.dequeue().getValue());
         
        
                    System.out.println(Q.isEmpty());

        
        
        
        
       
        
    }
    
}

