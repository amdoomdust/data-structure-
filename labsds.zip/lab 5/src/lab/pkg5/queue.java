/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dddoo
 */
public class queue implements QueueADT<E>{
 private int size, front, rear;
    private E data[];

    public queue(int size) {
        data = new E[size];
        front = rear = -1;
    }

    

    @Override
    public boolean isEmpty() {
        return (front == -1);
    }

    @Override
    public boolean full() {
        return (front == (rear + 1) % data.length);
    }

    @Override
    public void enqueue(E x) {
        if (full()) {
            System.out.println("Queue is full");

        } else {
            if (front == -1) {
                front = 0;
            }
            rear = (rear + 1) % data.length;
            data[rear] = x;
        }
    }

    @Override
    public E dequeue() {
        E e;
        if (isEmpty()) {
            System.out.println("Queue is empty");
            e = null;
        } else {
            e = data[front];
            if (front == rear) {
                front = rear = -1;
            } else {
                front = (front + 1) % data.length;
            }
        }
        return e;
    }

}