/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectds;

/**
 *
 * @author dddoo
 */
public interface LLinter<E> {
    
    void createrecord(E e);
    int deleterecord(int id);
    void showemp(int id);
    void updateemp(int id,String pnum,String adrs,int w_hour);
    void updatesalemp(int id);
    E smartsearch(int id);
    boolean checkrecord (E e );
        
    
    
   
    
}
