/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author NAWAF
 */
public class DoublyLinkedList implements List {

    private DNode head;

    @Override
    public void addFront(int x) {
        DNode node = new DNode(x);
        node.next = head;
        node.previous = null;
        if (head != null) {
            head.previous = node;
        }
        head = node;

    }

    @Override
    public void addEnd(int x) {
        DNode temp = head;
        DNode node = new DNode(x);

        if (head == null) {
            addFront(x);
        } else {
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = node;
            node.previous = temp;
            node.next = null;

        }

    }

    @Override
    public void addMid(int val, int x) {
        DNode temp = head;

        while (temp != null && temp.data != val) {
            temp = temp.next;
        }
        if (temp.data != val) {
            System.out.println("The list doesn't have this value");
        } else {
            DNode node = new DNode(x);

            node.next = temp.next;
            temp.next.previous = node;
            node.previous = temp;
            temp.next = node;

        }

    }

    @Override
    public void print() {
        DNode temp = head;

        while (temp != null) {
            System.out.println(temp.data );
            temp = temp.next;
        }
       
    }

    @Override
    public boolean empty() {
        if (head == null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void removeEnd() {
        if (empty()) {
            System.out.println("empty list");
        } else {
            DNode temp = head;

            while (temp.next != null) {
                temp = temp.next;
            }
            temp.previous.next = null;

            System.out.println("last node " + temp.data + "is deleted ");
        }
    }

    @Override
    public void removeFront() {
        if (empty()) {
            System.out.println("empty list");
        } else {
            DNode temp = head;//only for print the deleted node
            head = head.next;

            head.previous = null;
            System.out.println("first node " + temp.data + "is deleted ");
        }
    }

    @Override
    public void remove(int x) {

        if (empty()) {
            System.out.println("list is empty");
        }

        DNode temp = head;

        while (temp.next != null && temp.data != x) {
            temp = temp.next;
        }

        if (temp.data != x) {
            System.out.println("value is not in list" + x);

        } else {
            temp.previous.next = temp.next;
            temp.next.previous = temp.previous;
            System.out.println("Elment " + x + " has been deleted");
        }

    }

    @Override
    public void removeAll() {

        head = null;
    }

    @Override
    public boolean exist(int x) {
        DNode p = head;
        while (p != null) {
            if (p.data == x) {
                return true;
            }
            p = p.next;
        }
        return false;
    }
}
