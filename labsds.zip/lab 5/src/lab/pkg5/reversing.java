/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

/**
 *
 * @author dddoo
 */
public class reversing {
      public static void main(String[] args) {
        queue queue=new queue(9);
        Stack stack=new Stack();
        for(int i=1; i<=9; i++){
               E value=new E(i);
               queue.enqueue(value);
        }
        
         
        while (!queue.isEmpty()) {
            stack.push(queue.dequeue());
           
        }
        while (!stack.isEmpty()) {
            queue.enqueue((E) stack.top());
            stack.pop();
        }
        
        while (!queue.isEmpty()) {
            System.out.print(queue.dequeue().getValue()+ ", ");
           
        }
    }
}
